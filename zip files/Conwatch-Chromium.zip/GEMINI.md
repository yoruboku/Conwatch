# Project Overview

This project is a browser extension called **Conwatch**. It allows users to save their progress in videos on any website and resume watching later. It features a side panel to manage the saved video list, supports manual and automatic saving, and works across Chromium browsers and Firefox.

The extension is built using standard web technologies: JavaScript, HTML, and CSS. It does not use any external frameworks or libraries.

## Architecture

The extension is composed of three main parts:

1.  **Background Script (`background.js`)**: The central hub of the extension. It handles:
    *   Saving video data to `chrome.storage.local`.
    *   Managing keyboard shortcuts (`Alt+Shift+M` for manual save).
    *   Communicating between the content script and the side panel.
    *   Enabling the side panel on action click (Chrome).

2.  **Content Script (`content.js`)**: Injected into web pages. It is responsible for:
    *   Detecting the main video element on a page using a scoring algorithm.
    *   Extracting metadata (title, episode, thumbnail).
    *   Automatically saving video progress at regular intervals for whitelisted domains.
    *   Implementing the "resume" functionality by seeking to a specific timestamp from a URL hash (`#conwatch-t=...`).
    *   Sending video data to the background script when a save is triggered.

3.  **Side Panel (`sidepanel.html`, `sidepanel.js`, `sidepanel.css`)**: The user interface.
    *   Displays the list of saved videos, sorted by last watched and pinned status.
    *   Provides search functionality to filter the list.
    *   Allows users to play, pin, or delete videos from the list.
    *   Includes a settings modal to configure the theme (light/dark/auto) and the list of domains for auto-saving.
    *   The UI is styled with vanilla CSS, including support for both light and dark modes based on user preference or system settings.

# Building and Running

This project does not require a build step. It can be loaded directly as an unpacked extension in the browser.

### Chromium Browsers (Chrome, Brave, Edge)

1.  Open the browser and navigate to `chrome://extensions`.
2.  Enable the **"Developer mode"** toggle in the top-right corner.
3.  Click the **"Load unpacked"** button.
4.  Select the entire project directory (`D:\Projects\Conwatch-main`).

### Mozilla Firefox

1.  Open the browser and navigate to `about:debugging#/runtime/this-firefox`.
2.  Click the **"Load Temporary Add-on..."** button.
3.  Select the `manifest-firefox.json` file from the project directory.

# Development Conventions

*   **Code Style**: The JavaScript code is written in a functional style with clear, single-responsibility functions. It uses modern JavaScript features (ES6+) like `const`, `let`, arrow functions, and template literals. There is no linter or formatter configuration present, but the code is consistently formatted.
*   **Data Storage**: All persistent data (the watchlist and user settings) is stored in `chrome.storage.local`. The watchlist is a single array of objects, limited to the 50 most recent items.
*   **Communication**: Communication between the different parts of the extension is done via message passing (`chrome.runtime.sendMessage` and `chrome.tabs.sendMessage`).
*   **Cross-Browser Support**: The project maintains separate manifest files (`manifest-chromium.json` and `manifest-firefox.json`) to handle differences between the browser extension APIs. The core logic in the JavaScript files is largely cross-browser compatible.
